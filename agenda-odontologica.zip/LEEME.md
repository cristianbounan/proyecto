# Agenda Odontológica (APK Android)

Los turnos se guardan en una base SQLite dentro del celular (tablas `turnos` y `notas`).

## Opción A: compilar sin instalar nada (GitHub Actions)
1. Creá un repositorio PRIVADO en GitHub y subí el contenido de esta carpeta (el código no incluye datos de pacientes).
2. Pestaña "Actions" > "Compilar APK" > "Run workflow".
3. Al terminar, descargá el artefacto "agenda-apk", descomprimilo y pasá `app-debug.apk` al celular.
4. En el celular abrí el APK y permití "instalar apps de orígenes desconocidos".

## Opción B: compilar en tu PC (Windows)
Requisitos: Node 20+ y Android Studio.
```
npm install
npx cap add android
npx cap sync android
npx cap open android
```
En Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s). El archivo queda en `android/app/build/outputs/apk/debug/app-debug.apk`.

## Actualizar la app
Si cambiás `www/index.html`: `npx cap sync android` y volvé a compilar.
IMPORTANTE: Android solo actualiza sobre la app instalada si el APK está firmado con la misma clave. La opción A genera una clave distinta en cada compilación, así que habría que desinstalar la anterior y se perderían los datos. Antes, usá "Exportar copia" e importala después. La opción B reutiliza la clave de tu PC y actualiza sin perder datos.

## Copias de seguridad
"Exportar copia" genera un .json y abre el menú de compartir (Drive, WhatsApp, etc.). "Importar copia" lo restaura.
